-- --------------------------------------------------------
-- Host:                         localhost
-- Versión del servidor:         5.7.24 - MySQL Community Server (GPL)
-- SO del servidor:              Win64
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para emprendedores_old
DROP DATABASE IF EXISTS `emprendedores_old`;
CREATE DATABASE IF NOT EXISTS `emprendedores_old` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `emprendedores_old`;

-- Volcando estructura para tabla emprendedores_old.emprendedores
DROP TABLE IF EXISTS `emprendedores`;
CREATE TABLE IF NOT EXISTS `emprendedores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(500) NOT NULL,
  `emprendimiento` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) NOT NULL,
  `email` varchar(320) DEFAULT NULL,
  `comunicacion` bit(1) NOT NULL DEFAULT b'0',
  `fecha_actualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=825 DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla emprendedores_old.reuniones
DROP TABLE IF EXISTS `reuniones`;
CREATE TABLE IF NOT EXISTS `reuniones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emprendedor` int(11) DEFAULT NULL,
  `id_tipo_reunion` int(11) DEFAULT NULL,
  `estado` enum('Asistió','Registrado','Pagó','Dar Baja') DEFAULT 'Registrado',
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `fk_reunion_emprendedor` (`id_emprendedor`),
  KEY `fk_tipo_reunion` (`id_tipo_reunion`),
  CONSTRAINT `fk_reunion_emprendedor` FOREIGN KEY (`id_emprendedor`) REFERENCES `emprendedores` (`id`),
  CONSTRAINT `fk_tipo_reunion` FOREIGN KEY (`id_tipo_reunion`) REFERENCES `tipos_reuniones` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla emprendedores_old.tipos_reuniones
DROP TABLE IF EXISTS `tipos_reuniones`;
CREATE TABLE IF NOT EXISTS `tipos_reuniones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `descipcion` varchar(500) DEFAULT NULL,
  `capacidad` int(11) NOT NULL DEFAULT '0',
  `fecha_creacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- La exportación de datos fue deseleccionada.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
